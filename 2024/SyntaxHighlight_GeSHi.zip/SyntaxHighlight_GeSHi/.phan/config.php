<?php

return require __DIR__ . '/../vendor/mediawiki/mediawiki-phan-config/src/config.php';
