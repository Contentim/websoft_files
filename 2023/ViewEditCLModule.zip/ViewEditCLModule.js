
/**
 * @function ViewEditCLModule
 * @memberof Websoft.WT.CLOnline
 * @author IG BG
 * @description Просмотр/редактирование модуля курса CourseLab по ID
 * @param {integer} iPersonID - ID пользователя
 * @param {integer} iIdCLModule - ID модуля
 * @param {string} sHost - Хост
 * @param {string} sMode - Просмотр/Редактирование
 * @returns {ReturnWTLPEForm}
*/
function ViewEditCLModule(iPersonID, iIdCLModule, sHost, sMode){
	
	if(sHost == undefined){
		sHost = ''
	}

	oRes = tools.get_code_library_result_object();
	oRes.action_result = {}; 
	
	var iCLModuleID = OptInt(iIdCLModule)
	if(iCLModuleID == undefined)
	{
		oRes.action_result = {command: "alert", msg: "Не корректный ID модуля: [" + iIdCLModule + "]"};
		return oRes;
	}
	
	var bAccessStatus, redirect_url
	var	docModule = tools.open_doc(iCLModuleID)
	if(docModule == undefined)
	{
		oRes.action_result = {command: "alert", msg: "Не найден модуль с ID: [" + iCLModuleID + "]"};
		return oRes;
	}
	
	if(docModule.TopElem.Name != "cl_module")
	{
		oRes.action_result = {command: "alert", msg: "Полученный ID: [" + iCLModuleID + "] не является ID модуля курса: [" + docModule.TopElem.Name + "]"};
		return oRes;
	}
	
	
	var xmCourse = docModule.TopElem.cl_course_id.OptForeignElem;
	if(xmCourse != undefined && ArrayOptFind(xmCourse.author_id, 'This.Value == ' + iPersonID) == undefined )
	{
		oRes.action_result = {command: "alert", msg: "Текущий пользователь не является автором курса"};
		return oRes;
	}
	
	iCourseID = xmCourse.id.Value

	switch(sMode){
		case 'edit':
			redirect_url = sHost + '/clo?cl_course_id=' + iCourseID
			break;
		case 'view':
			redirect_url = sHost + '/courselab3/source/module/start.html?module_id=' + iIdCLModule
			break;
	}
	
	//oRes.action_result = {command: "new_window ", url: redirect_url};
	oRes.action_result = {command: "redirect", redirect_url: redirect_url};

	return oRes;
}

